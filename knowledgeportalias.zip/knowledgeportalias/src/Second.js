import React from 'react';
import axios from "axios";
import {useEffect, useState} from "React";
const Second=()=>{

    useEffect(() => {
        axios.get('https://mdelab2-core1.centralus.cloudapp.azure.com:8000/api/v2/profiles')
        .then(response=>{
          console.log(response.data);
        })
        alert("Second component is mounted");
        console.log("Second component is mounted");
      }, []);


    // const [responseData, SetresponseData]=useState();
    // useEffect(() => {
    //     axios.get('https://jsonplaceholder.typicode.com/posts')
    //     .then(response=>{
    //             console.log(response.data);
    //             SetresponseData(response.data);
    //         })
    //     .catch((error)=>{
    //         console.log("error", error);
    //         alert("error");
    //     })
    //     alert("Second component is mounted");
    //     console.log("Second component is mounted");
    //   }, []);

    return(
        <>
    <div>Second component invoked</div>
    {/* {responseData} */}
    </>
    );
}
export default Second;